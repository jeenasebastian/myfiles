from ...extra.search import MaxViolation

def test_init_violn():
    v = MaxViolation()
